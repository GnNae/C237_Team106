Update.ejs - (80% done) need some testing.
Update for the js need troubleshooting and testing.


Ean: 
Search.ejs is about done, just need to do actual testing with the codes of others. Issues faced? Search function was harder to do because it was not went through in class that it was copy paste with just some minor editing.

app.js  in progress...
remember to install express before submission